﻿
using PlantSystem;
using System.Collections;
using UnityEngine;

public class Water : MonoBehaviour
{
    [SerializeField] public GameObject waterSprite;
    [SerializeField] private ParticleSystem waterParticles;
    [Header("检测范围")]
    [SerializeField] private float radius = 10;

    [SerializeField] private float angle = 60;

    [SerializeField] private Transform mouthPos;
    [SerializeField] private Transform kettlePos;
    private Coroutine _waterCoroutine;

    [Header("Gizmo设置")]
    [SerializeField] private Color sectorColor = new Color(1f, 1f, 1f, 0.3f); // 扇形区域颜色，带透明度
    [SerializeField] private Color inSectorColor = Color.green; // 点在扇形内的颜色
    [SerializeField] private Color outOfSectorColor = Color.red; // 点在扇形外的颜色
    private WaitForSeconds _waterWaitForSeconds = new WaitForSeconds(0.3f);
    private Vector3 _waterPosition = Vector3.up * 1000;
    private bool _isShowing = false;

    public void ShowWater()
    {
        waterSprite.SetActive(true);
        Cursor.visible = false;
        _isShowing = true;
    }

    public void HideWater()
    {
        this.transform.position = _waterPosition;
        waterSprite.SetActive(false);
        Cursor.visible = true;
        _isShowing = false;
        waterParticles.Stop(); // 停止粒子效果
        //AudioManager.Instance.StopFadeLoopSFX("Watering");
    }

    private void Update()
    {
        if (!_isShowing) return;
        if (Input.GetMouseButtonDown(1))
        {
            HideWater();
            return;
        }

        // 按下鼠标左键时启动协程
        if (Input.GetMouseButtonDown(0))
        {
            // 先确保没有正在运行的协程
            if (_waterCoroutine != null)
            {
                StopCoroutine(_waterCoroutine);
            }
            _waterCoroutine = StartCoroutine(WaterRoutine());
            waterParticles.Play(); // 播放粒子效果
            //AudioManager.Instance.StartFadeLoopSFX("Watering",2.5f,false);
        }

        // 松开鼠标左键时停止协程和粒子效果
        if (Input.GetMouseButtonUp(0))
        {
            if (_waterCoroutine != null)
            {
                StopCoroutine(_waterCoroutine);
                _waterCoroutine = null;
            }
            waterParticles.Stop(); // 停止粒子效果
            //AudioManager.Instance.StopFadeLoopSFX("Watering");
        }

        // 获取鼠标的屏幕位置
        Vector3 mouseScreenPosition = Input.mousePosition;

        // 将屏幕坐标转换为世界坐标
        Vector3 mouseWorldPosition = Camera.main.ScreenToWorldPoint(mouseScreenPosition);
        mouseWorldPosition.z = 20;
        // 更新物体的位置
        transform.position = mouseWorldPosition;
    }



    private IEnumerator WaterRoutine()
    {
        while (true) // 循环执行直到被停止[1,5](@ref)
        {
            this.WaterPlantInRange(); // 执行植物灌溉方法
            yield return _waterWaitForSeconds; // 等待0.3秒[1,3](@ref)
        }
    }

    private void WaterPlantInRange()
    {
        foreach (var plant in PlantManager.Instance.GetAllPlants())
        {
            if (IsPointInSectorOptimized(mouthPos.position, mouthPos.position - kettlePos.position,
                    radius, angle, plant.transform.position))
            {
                plant.Irrigate();
            }
        }
    }

    /// <summary>
    /// 判断目标点是否在扇形区域内 
    /// </summary>
    /// <param name="origin">扇形圆心位置</param>
    /// <param name="direction">扇形中轴线方向</param>
    /// <param name="radius">扇形半径</param>
    /// <param name="angle">扇形总角度（度）</param>
    /// <param name="targetPoint">要判断的目标点</param>
    /// <returns>点在扇形内返回 true，否则返回 false</returns>
    private bool IsPointInSectorOptimized(Vector2 origin, Vector2 direction, float radius, float angle, Vector2 targetPoint)
    {
        Vector3 originToPoint = targetPoint - origin;
        if (originToPoint.sqrMagnitude > radius * radius)
            return false;

        Vector3 dirNormalized = direction.normalized;
        Vector3 pointDirNormalized = originToPoint.normalized;

        // 使用点积计算夹角余弦值
        float dotProduct = Vector3.Dot(dirNormalized, pointDirNormalized);

        // 计算扇形半角对应的余弦值（只需计算一次，可缓存）
        float cosHalfAngle = Mathf.Cos((angle / 2) * Mathf.Deg2Rad);

        // 直接比较余弦值：余弦值越大，夹角越小
        return dotProduct >= cosHalfAngle;
    }

    void OnDrawGizmos()
    {
        if (mouthPos == null || kettlePos == null)
            return;

        // 计算方向：从mouthPos指向kettlePos
        Vector3 sectorDirection = (mouthPos.position - kettlePos.position).normalized;

        // 绘制扇形区域
        DrawSectorGizmo3D(mouthPos.position, sectorDirection, radius, angle, sectorColor);

        foreach (var plant in PlantManager.Instance.GetAllPlants())
        {
            bool isInSector = IsPointInSectorOptimized(mouthPos.position, sectorDirection, radius, angle, plant.transform.position);

            // 绘制目标点
            Gizmos.color = isInSector ? inSectorColor : outOfSectorColor;
            Gizmos.DrawSphere(plant.transform.position, 0.2f);


            // 绘制从圆心到目标点的连线
            Gizmos.color = Color.white;
            Gizmos.DrawLine(mouthPos.position, plant.transform.position);
        }

        // 检测植物
        foreach (var plant in PlantManager.Instance.GetAllPlants())
        {
            bool isInSector = IsPointInSectorOptimized(mouthPos.position, sectorDirection, radius, angle, plant.transform.position);

            // 绘制目标点
            Gizmos.color = isInSector ? inSectorColor : outOfSectorColor;
            Gizmos.DrawSphere(plant.transform.position, 0.2f);


            // 绘制从圆心到目标点的连线
            Gizmos.color = Color.white;
            Gizmos.DrawLine(mouthPos.position, plant.transform.position);
        }
        // 检测目标点

    }

    private void DrawSectorGizmo3D(Vector3 origin, Vector3 direction, float radius, float angle, Color color)
    {
        Gizmos.color = color;

        // 确保方向已归一化
        direction.Normalize();

        // 计算垂直于方向向量的参考轴
        Vector3 perpendicularAxis;
        if (Mathf.Abs(Vector3.Dot(direction, Vector3.up)) > 0.9f)
        {
            // 如果方向几乎垂直，使用不同的参考轴
            perpendicularAxis = Vector3.Cross(direction, Vector3.forward).normalized;
        }
        else
        {
            // 使用与方向和上向量都垂直的轴
            perpendicularAxis = Vector3.Cross(direction, Vector3.up).normalized;
        }

        // 计算扇形的左右边界
        float halfAngle = angle / 2f;
        Quaternion leftRot = Quaternion.AngleAxis(-halfAngle, perpendicularAxis);
        Quaternion rightRot = Quaternion.AngleAxis(halfAngle, perpendicularAxis);

        Vector3 leftBoundary = leftRot * direction * radius;
        Vector3 rightBoundary = rightRot * direction * radius;

        // 绘制扇形边界线
        Gizmos.DrawLine(origin, origin + leftBoundary);
        Gizmos.DrawLine(origin, origin + rightBoundary);

        // 绘制扇形弧线
        int segments = Mathf.Max(20, Mathf.FloorToInt(angle / 2f));
        float step = angle / segments;

        Vector3 prevPoint = origin + leftBoundary;
        for (int i = 1; i <= segments; i++)
        {
            Quaternion rot = Quaternion.AngleAxis(-halfAngle + step * i, perpendicularAxis);
            Vector3 nextPoint = origin + rot * direction * radius;
            Gizmos.DrawLine(prevPoint, nextPoint);
            prevPoint = nextPoint;
        }

        // 绘制扇形填充（使用多个三角形）
        for (int i = 0; i < segments; i++)
        {
            float currentAngle = -halfAngle + step * i;
            float nextAngle = -halfAngle + step * (i + 1);

            Quaternion currentRot = Quaternion.AngleAxis(currentAngle, perpendicularAxis);
            Quaternion nextRot = Quaternion.AngleAxis(nextAngle, perpendicularAxis);

            Vector3 currentPoint = origin + currentRot * direction * radius * 0.98f;
            Vector3 nextPoint = origin + nextRot * direction * radius * 0.98f;

            // 绘制填充三角形
            Gizmos.DrawLine(origin, currentPoint);
            Gizmos.DrawLine(origin, nextPoint);
            Gizmos.DrawLine(currentPoint, nextPoint);
        }

        // 绘制方向指示线
        Gizmos.color = Color.blue;
        Gizmos.DrawLine(origin, origin + direction * radius);
    }

}
