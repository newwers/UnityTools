﻿using StoneSystem;
using System.Collections.Generic;
using UnityEngine;

namespace PlantSystem
{
    public class Plant : MonoBehaviour
    {
        [Header("基本信息")]
        public string instanceId;
        public Stone stoneRef;

        [Header("植物数据")]
        public PlantDataSO plantData;

        [Header("生长状态")]
        [Range(0, 100)] public float currentGrowthValue;
        public int currentStageIndex;

        [Header("灌溉状态")]
        [Range(0, 100)] public float currentIrrigationValue;

        [Header("渲染状态")]
        public SpriteRenderer spriteRenderer;

        [Header("落叶状态")]
        private List<GameObject> leafPool = new List<GameObject>();
        private float nextLeafSpawnTime;
        private MouseInteraction mouseInteraction;
        private BoxCollider2D boxCollider;

        private void Awake()
        {
            boxCollider = GetComponent<BoxCollider2D>();

            // 初始化SpriteRenderer
            if (spriteRenderer == null)
            {
                spriteRenderer = GetComponent<SpriteRenderer>();
            }

            // 初始化实例id
            if (string.IsNullOrEmpty(instanceId))
            {
                instanceId = System.Guid.NewGuid().ToString();
            }

            if (plantData != null)
            {
                // 初始化生长值
                currentGrowthValue = 0;
                currentIrrigationValue = plantData.irrigationValue;
                currentStageIndex = 0;



                // 更新植物图标
                UpdatePlantIcon();

                // 初始化落叶生成时间
                ResetLeafSpawnTime();
            }

            // 初始化 MouseInteraction 引用
            mouseInteraction = GetComponent<MouseInteraction>();
        }

        /// <summary>
        /// 触发植物晃动
        /// </summary>
        public void TriggerShake()
        {
            if (mouseInteraction != null)
            {
                mouseInteraction.StartShake();
            }
        }

        private void UpdatePlantIcon()
        {
            if (plantData != null && spriteRenderer != null)
            {
                // 获取当前阶段的配置
                PlantStageConfig currentStageConfig = GetCurrentStageConfig();
                if (currentStageConfig != null && currentStageConfig.icon != null)
                {
                    // 更新SpriteRenderer的sprite
                    spriteRenderer.sprite = currentStageConfig.icon;
                    SpriteUtil.AdjustBoxCollider(spriteRenderer, boxCollider);
                }
            }
        }


        private void Update()
        {
            if (plantData == null) return;

            // 更新生长值
            UpdateGrowth();

            // 更新灌溉值
            //UpdateIrrigation();

            // 更新落叶生成
            UpdateLeafGeneration();
        }

        private void UpdateGrowth()
        {
            // 基础生长速度
            float baseGrowthSpeed = 1f;

            // 计算本次可以消耗的灌溉值
            float availableIrrigation = currentIrrigationValue;
            float maxPossibleGrowth = availableIrrigation / plantData.irrigationToGrowthRatio;

            // 计算实际生长量（基于时间和基础生长速度）
            float growthAmount = baseGrowthSpeed * Time.deltaTime;

            // 限制生长量不超过最大可能生长量
            growthAmount = Mathf.Min(growthAmount, maxPossibleGrowth);

            // 计算实际需要消耗的灌溉值
            float requiredIrrigation = growthAmount * plantData.irrigationToGrowthRatio;

            // 只有当有足够的灌溉值时，才增加生长值并减少灌溉值
            if (requiredIrrigation > 0 && currentIrrigationValue >= requiredIrrigation)
            {
                // 更新生长值
                currentGrowthValue += growthAmount;

                // 减少灌溉值
                currentIrrigationValue -= requiredIrrigation;
                currentIrrigationValue = Mathf.Max(0, currentIrrigationValue);
            }

            // 检查是否需要进入下一阶段
            if (currentGrowthValue >= 100 && currentStageIndex < plantData.stageConfigs.Length - 1)
            {
                currentGrowthValue = 0;
                currentStageIndex++;
                OnStageChanged();
            }

            // 确保生长值不超过100
            currentGrowthValue = Mathf.Clamp(currentGrowthValue, 0, 100);
        }

        private void UpdateIrrigation()
        {
            // 每秒自动降低灌溉值
            currentIrrigationValue -= plantData.irrigationDecreaseSpeed * Time.deltaTime;
            currentIrrigationValue = Mathf.Clamp(currentIrrigationValue, 0, 100);
        }

        private void UpdateLeafGeneration()
        {
            if (Time.time >= nextLeafSpawnTime && leafPool.Count < plantData.maxLeafStorage)
            {
                SpawnLeaf();
                ResetLeafSpawnTime();
            }
        }

        public void Irrigate()
        {
            // 增加灌溉值
            currentIrrigationValue += plantData.irrigationAbsorbValue;
            currentIrrigationValue = Mathf.Clamp(currentIrrigationValue, 0, 100);
        }

        private void SpawnLeaf()
        {
            if (plantData.leafPrefab != null)
            {
                // 生成落叶
                GameObject leaf = Instantiate(plantData.leafPrefab, transform.position, Quaternion.identity);
                leafPool.Add(leaf);

                // 添加落叶销毁逻辑
                Destroy(leaf, 10f); // 10秒后自动销毁
            }
        }

        private void ResetLeafSpawnTime()
        {
            // 随机设置下次落叶生成时间
            float spawnTime = Random.Range(plantData.leafSpawnMinTime, plantData.leafSpawnMaxTime);
            nextLeafSpawnTime = Time.time + spawnTime;
        }

        private void OnStageChanged()
        {
            // 当植物进入新阶段时的回调
            Debug.Log($"植物 {plantData.plantName} 进入阶段 {plantData.stageConfigs[currentStageIndex].stageName}");

            // 更新植物图标
            UpdatePlantIcon();
        }

        public PlantStageConfig GetCurrentStageConfig()
        {
            if (plantData != null && currentStageIndex >= 0 && currentStageIndex < plantData.stageConfigs.Length)
            {
                return plantData.stageConfigs[currentStageIndex];
            }
            return null;
        }

        private void OnDestroy()
        {
            // 清理落叶
            foreach (var leaf in leafPool)
            {
                if (leaf != null)
                {
                    Destroy(leaf);
                }
            }
            leafPool.Clear();
        }
    }
}
