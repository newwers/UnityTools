using UnityEngine;
using Z.UI;


#if UNITY_EDITOR
using UnityEditor;
#endif

namespace PlantSystem
{

    [CreateAssetMenu(fileName = "NewPlantData", menuName = "Plant System/Plant Data", order = 1)]
    public class PlantDataSO : ScriptableObject
    {
        [Header("基本信息")]
        [FieldReadOnly]
        public string guid;
        public string plantName;
        public Plant prefab;
        public Rarity rarity;

        [Header("生成配置")]
        public SpawnTag[] spawnTags;
        public SizeTag sizeTag;

        [Header("生长配置")]
        public PlantStageConfig[] stageConfigs;

        [Header("灌溉配置")]
        [Range(0, 100), Tooltip("灌溉值")] public float irrigationValue;
        [Tooltip("灌溉吸收值")] public float irrigationAbsorbValue;
        [Tooltip("灌溉减少速度")] public float irrigationDecreaseSpeed;
        [Tooltip("消耗多少灌溉值增加一点生长值")] public float irrigationToGrowthRatio = 1;

        [Header("落叶配置")]
        public GameObject leafPrefab;
        [Range(10, 30), Tooltip("最小落叶生成时间")] public float leafSpawnMinTime;
        [Range(10, 30), Tooltip("最大落叶生成时间")] public float leafSpawnMaxTime;
        public int maxLeafStorage;

        private void OnEnable()
        {
            if (string.IsNullOrEmpty(guid))
            {
                guid = System.Guid.NewGuid().ToString();
            }
        }

    }



#if UNITY_EDITOR
    [CustomEditor(typeof(PlantDataSO))]
    [CanEditMultipleObjects]
    public class PlantDataSOEditor : Editor
    {
        PlantDataSO so;

        private void OnEnable()
        {
            so = target as PlantDataSO;
        }

        public override void OnInspectorGUI()
        {
            // 绘制默认的Inspector界面
            DrawDefaultInspector();

            if (so)
            {
                for (int i = 0; i < so.stageConfigs.Length; i++)
                {
                    UIUtil.ShowSpritePreview(so.stageConfigs[i].icon, $"阶段 {i + 1} - {so.stageConfigs[i].stageName} 图标预览");
                }
            }

            // 添加跳转到文件按钮
            if (GUILayout.Button("跳转到文件", GUILayout.Height(24)))
            {
                // 选中并高亮显示对应的 Asset 文件
                Selection.activeObject = target;
                EditorGUIUtility.PingObject(target);
            }
        }


    }
#endif

    [System.Serializable]
    public class PlantStageConfig
    {
        public string stageName;
        public Sprite icon;
    }

    public enum Rarity
    {
        [InspectorName("普通")]
        Common,
        [InspectorName("稀有")]
        Rare,
        [InspectorName("史诗")]
        Epic,
        [InspectorName("传奇")]
        Legendary
    }

    [System.Flags]
    public enum SpawnTag
    {
        [InspectorName("无")]
        None = 0,
        [InspectorName("平地")]
        Flat = 1,
        [InspectorName("斜坡")]
        Slope = 2,
        [InspectorName("悬挂")]
        Hanging = 4,
        [InspectorName("中心")]
        Center = 8,
        [InspectorName("侧面")]
        Side = 16
    }

    public enum SizeTag
    {
        [InspectorName("大型")]
        Large,
        [InspectorName("中型")]
        Medium,
        [InspectorName("小型")]
        Small
    }

}

