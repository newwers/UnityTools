using UnityEngine;
using System.Collections.Generic;
using StoneSystem;

namespace PlantSystem
{
    public class PlantManager : MonoBehaviour
    {
        [Header("植物管理器")]
        private List<Plant> plants = new List<Plant>();
        private static PlantManager instance;

        [Header("可种植植物配置")]
        public PlantDataSO[] availablePlants;

        public static PlantManager Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = FindObjectOfType<PlantManager>();
                    if (instance == null)
                    {
                        GameObject obj = new GameObject("PlantManager");
                        instance = obj.AddComponent<PlantManager>();
                    }
                }
                return instance;
            }
        }

        private void Awake()
        {
            if (instance == null)
            {
                instance = this;
                DontDestroyOnLoad(gameObject);
            }
            else if (instance != this)
            {
                Destroy(gameObject);
            }
        }

        private void Start()
        {
            // 初始化时收集场景中的所有植物
            CollectPlants();
        }

        /// <summary>
        /// 收集场景中的所有植物
        /// </summary>
        public void CollectPlants()
        {
            plants.Clear();
            Plant[] plantArray = FindObjectsOfType<Plant>();
            foreach (var plant in plantArray)
            {
                plants.Add(plant);
            }
        }

        /// <summary>
        /// 添加植物到管理器
        /// </summary>
        /// <param name="plant">要添加的植物</param>
        public void AddPlant(Plant plant)
        {
            if (plant != null && !plants.Contains(plant))
            {
                plants.Add(plant);
            }
        }

        /// <summary>
        /// 从管理器中移除植物
        /// </summary>
        /// <param name="plant">要移除的植物</param>
        public void RemovePlant(Plant plant)
        {
            if (plant != null && plants.Contains(plant))
            {
                plants.Remove(plant);
            }
        }

        /// <summary>
        /// 获取场景中的所有植物
        /// </summary>
        /// <returns>植物列表</returns>
        public List<Plant> GetAllPlants()
        {
            return plants;
        }

        /// <summary>
        /// 根据植物数据获取植物
        /// </summary>
        /// <param name="plantData">植物数据</param>
        /// <returns>植物列表</returns>
        public List<Plant> GetPlantsByData(PlantDataSO plantData)
        {
            List<Plant> result = new List<Plant>();
            foreach (var plant in plants)
            {
                if (plant.plantData == plantData)
                {
                    result.Add(plant);
                }
            }
            return result;
        }

        /// <summary>
        /// 为所有植物浇水
        /// </summary>
        public void IrrigateAllPlants()
        {
            foreach (var plant in plants)
            {
                plant.Irrigate();
            }
        }

        /// <summary>
        /// 生成新植物
        /// </summary>
        /// <param name="plantData">植物数据</param>
        /// <param name="position">生成位置</param>
        /// <param name="rotation">生成旋转</param>
        /// <param name="stone">石头引用</param>
        /// <returns>生成的植物</returns>
        public Plant SpawnPlant(PlantDataSO plantData, Vector3 position, Quaternion rotation, StoneSystem.Stone stone = null)
        {
            if (plantData == null)
            {
                Debug.LogError("植物数据不能为空");
                return null;
            }

            Plant plant = null;
            GameObject plantObj = null;

            // 检查PlantDataSO中是否有prefab
            if (plantData.prefab != null)
            {
                // 使用prefab创建植物
                plantObj = Instantiate(plantData.prefab.gameObject, position, rotation);
                plant = plantObj.GetComponent<Plant>();
                if (plant != null)
                {
                    plant.plantData = plantData;
                    plant.stoneRef = stone;
                }
            }
            else
            {
                // 没有prefab，使用当前的创建方式
                plantObj = new GameObject(plantData.plantName);
                plantObj.transform.position = position;
                plantObj.transform.rotation = rotation;

                // 添加Plant组件
                plant = plantObj.AddComponent<Plant>();
                plant.plantData = plantData;
                plant.stoneRef = stone;
            }

            // 设置父物体
            if (plantObj != null && stone != null && stone.flowerParent != null)
            {
                plantObj.transform.parent = stone.flowerParent;
            }

            // 添加到管理器
            if (plant != null)
            {
                AddPlant(plant);
            }

            return plant;
        }

        /// <summary>
        /// 清理所有植物
        /// </summary>
        public void ClearAllPlants()
        {
            foreach (var plant in plants)
            {
                if (plant != null)
                {
                    Destroy(plant.gameObject);
                }
            }
            plants.Clear();
        }

        /// <summary>
        /// 获取所有可以种植的植物信息
        /// </summary>
        /// <returns>可种植的植物信息数组</returns>
        public PlantDataSO[] GetAllPlantData()
        {
            return availablePlants;
        }
    }
}
