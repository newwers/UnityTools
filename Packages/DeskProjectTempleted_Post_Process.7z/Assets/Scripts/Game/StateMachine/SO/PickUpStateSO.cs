using UnityEngine;

namespace StateMachineSystem
{
    [CreateAssetMenu(fileName = "PickUpState", menuName = "StateMachine/PickUpState", order = 6)]
    public class PickUpStateSO : StateSO
    {
        private void OnEnable()
        {
            stateType = StateType.PickUp;
        }
    }
}