﻿using UnityEngine;

namespace StateMachineSystem
{
    [CreateAssetMenu(fileName = "StandState", menuName = "StateMachine/StandState", order = 3)]
    public class StandStateSO : StateSO
    {
        [Header("Transition Probabilities")]
        [Range(0, 100)]
        public int standToLieProbability = 20;

        [Range(0, 100)]
        public int standToWalkProbability = 60;


        private void OnEnable()
        {
            stateType = StateType.Stand;
        }
    }
}
