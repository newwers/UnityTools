using UnityEngine;

namespace StateMachineSystem
{
    [CreateAssetMenu(fileName = "StandToLieState", menuName = "StateMachine/StandToLieState", order = 6)]
    public class StandToLieSO : StateSO
    {
        private void OnEnable()
        {
            stateType = StateType.StandToLie;
        }
    }
}