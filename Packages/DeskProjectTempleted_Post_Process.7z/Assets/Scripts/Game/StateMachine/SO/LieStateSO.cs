using UnityEngine;

namespace StateMachineSystem
{
    [CreateAssetMenu(fileName = "LieState", menuName = "StateMachine/LieState", order = 2)]
    public class LieStateSO : StateSO
    {
        [Header("Transition Probabilities")]
        [Range(0, 100)]
        public int lieToStandProbability = 50;
        
        private void OnEnable()
        {
            stateType = StateType.Lie;
        }
    }
}
