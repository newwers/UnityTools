using UnityEngine;

namespace StateMachineSystem
{
    [CreateAssetMenu(fileName = "LieToStandState", menuName = "StateMachine/LieToStandState", order = 5)]
    public class LieToStandSO : StateSO
    {
        private void OnEnable()
        {
            stateType = StateType.LieToStand;
        }
    }
}