using System;

namespace StateMachineSystem
{
    [Serializable]
    public enum StateType
    {
        Lie,
        Stand,
        Walk,
        LieToStand,
        StandToLie,
        PickUp
    }
}
