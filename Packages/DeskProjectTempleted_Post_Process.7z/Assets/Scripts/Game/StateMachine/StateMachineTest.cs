using UnityEngine;
using StateMachineSystem;

public class StateMachineTest : MonoBehaviour
{
    private StateMachine stateMachine;
    
    private void Start()
    {
        stateMachine = GetComponent<StateMachine>();
        if (stateMachine == null)
        {
            stateMachine = gameObject.AddComponent<StateMachine>();
        }
        
        Debug.Log("StateMachineTest: State machine initialized");
        Debug.Log($"Initial state: {stateMachine.currentStateType}");
    }
    
    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            Debug.Log($"Current state: {stateMachine.currentStateType}");
        }
        
        if (Input.GetKeyDown(KeyCode.L))
        {
            stateMachine.SetState(StateType.Lie);
        }
        
        if (Input.GetKeyDown(KeyCode.S))
        {
            stateMachine.SetState(StateType.Stand);
        }
        
        if (Input.GetKeyDown(KeyCode.W))
        {
            stateMachine.SetState(StateType.Walk);
        }
    }
}
