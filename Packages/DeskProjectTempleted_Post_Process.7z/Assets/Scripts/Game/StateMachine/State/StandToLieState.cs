using UnityEngine;

namespace StateMachineSystem
{
    public class StandToLieState : StateBase
    {
        public override StateType StateType { get { return StateType.StandToLie; } }

        public override StateType GetNextState()
        {
            // 过渡状态，直接进入Lie状态
            return StateType.Lie;
        }

        public override void Enter()
        {
            base.Enter();

            // 重置所有动画参数
            stateMachine.ResetAllAnimatorBools();

            // 播放StandToLie动画
            stateMachine.SetAnimatorBool("StandToLie", true);

            // 进入过渡状态的逻辑
        }

        public override void Exit()
        {
            base.Exit();

            // 重置StandToLie动画参数
            stateMachine.SetAnimatorBool("StandToLie", false);

            // 退出过渡状态的逻辑
        }
    }
}