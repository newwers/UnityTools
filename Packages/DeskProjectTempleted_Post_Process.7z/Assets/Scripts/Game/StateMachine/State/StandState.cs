﻿using UnityEngine;

namespace StateMachineSystem
{
    public class StandState : StateBase
    {
        protected new StandStateSO stateConfig;

        public override StateType StateType { get { return StateType.Stand; } }

        public override void Initialize(StateMachine machine, StateSO config)
        {
            base.Initialize(machine, config);
            stateConfig = config as StandStateSO;
        }

        public override StateType GetNextState()
        {
            int randomValue = Random.Range(0, 100);

            int lieProb = stateConfig.standToLieProbability;
            int walkProb = lieProb + stateConfig.standToWalkProbability;

            if (randomValue < lieProb)
            {
                return StateType.StandToLie;
            }
            else if (randomValue < walkProb)
            {
                return StateType.Walk;
            }

            return StateType.Stand;
        }

        public override void Enter()
        {
            base.Enter();

            // 重置所有动画参数
            stateMachine.ResetAllAnimatorBools();

            // 播放Stand动画
            stateMachine.SetAnimatorBool("Stand", true);

            // 进入站立状态的逻辑
        }

        public override void Exit()
        {
            base.Exit();

            // 重置Stand动画参数
            stateMachine.SetAnimatorBool("Stand", false);

            // 退出站立状态的逻辑
        }
    }
}
