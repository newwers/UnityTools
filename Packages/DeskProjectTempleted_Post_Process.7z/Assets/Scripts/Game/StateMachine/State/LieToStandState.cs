using UnityEngine;

namespace StateMachineSystem
{
    public class LieToStandState : StateBase
    {
        public override StateType StateType { get { return StateType.LieToStand; } }

        public override StateType GetNextState()
        {
            // 过渡状态，直接进入Stand状态
            return StateType.Stand;
        }

        public override void Enter()
        {
            base.Enter();

            // 重置所有动画参数
            stateMachine.ResetAllAnimatorBools();

            // 播放LieToStand动画
            stateMachine.SetAnimatorBool("LieToStand", true);

            // 进入过渡状态的逻辑
        }

        public override void Exit()
        {
            base.Exit();

            // 重置LieToStand动画参数
            stateMachine.SetAnimatorBool("LieToStand", false);

            // 退出过渡状态的逻辑
        }
    }
}