using UnityEngine;

namespace StateMachineSystem
{
    public class PickUpState : StateBase
    {
        protected new PickUpStateSO stateConfig;

        public override StateType StateType { get { return StateType.PickUp; } }

        public override void Initialize(StateMachine machine, StateSO config)
        {
            base.Initialize(machine, config);
            stateConfig = config as PickUpStateSO;
        }

        public override StateType GetNextState()
        {
            // 被拿起状态默认保持不变，需要外部触发才能退出
            return StateType.PickUp;
        }

        public override void Enter()
        {
            base.Enter();

            // 重置所有动画参数
            stateMachine.ResetAllAnimatorBools();

            // 播放PickUp动画
            stateMachine.SetAnimatorBool("PickUp", true);

            // 进入被拿起状态的逻辑
        }

        public override void Exit()
        {
            base.Exit();

            // 重置PickUp动画参数
            stateMachine.SetAnimatorBool("PickUp", false);

            // 退出被拿起状态的逻辑
        }
    }
}