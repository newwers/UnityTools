﻿﻿using UnityEngine;

namespace StateMachineSystem
{
    public class LieState : StateBase
    {
        protected new LieStateSO stateConfig;

        public override StateType StateType { get { return StateType.Lie; } }

        public override void Initialize(StateMachine machine, StateSO config)
        {
            base.Initialize(machine, config);
            stateConfig = config as LieStateSO;
        }

        public override StateType GetNextState()
        {
            // 获取石头的 Stone 组件
            StoneSystem.Stone stone = stateMachine.Stone;

            // 检查石头是否有符合条件的植物
            if (stone != null && !stone.HasEligiblePlants())
            {
                // 石头上没有植物或所有植物灌溉值不高于5，保持 Lie 状态
                return StateType.Lie;
            }

            // 有符合条件的植物，继续执行原有的状态切换逻辑
            int randomValue = Random.Range(0, 100);

            if (randomValue < stateConfig.lieToStandProbability)
            {
                return StateType.LieToStand;
            }

            return StateType.Lie;
        }

        public override void Enter()
        {
            base.Enter();

            // 重置所有动画参数
            stateMachine.ResetAllAnimatorBools();

            // 播放Lie动画
            stateMachine.SetAnimatorBool("Lie", true);

            // 进入趴状态的逻辑
        }

        public override void Exit()
        {
            base.Exit();

            // 重置Lie动画参数
            stateMachine.SetAnimatorBool("Lie", false);

            // 退出趴状态的逻辑
        }
    }
}
