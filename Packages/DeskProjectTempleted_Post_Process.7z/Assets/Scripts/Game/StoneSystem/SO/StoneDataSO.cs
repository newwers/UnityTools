﻿﻿using UnityEngine;
using Z.UI;


#if UNITY_EDITOR
using UnityEditor;
#endif

namespace StoneSystem
{

    [CreateAssetMenu(fileName = "NewStoneData", menuName = "Stone System/Stone Data", order = 1)]
    public class StoneDataSO : ScriptableObject
    {
        [Header("基本信息")]
        [FieldReadOnly]
        public string guid;
        public string stoneName;
        public Sprite icon;

        [Header("移动配置")]
        public float moveSpeed;

        [Header("可种植区域配置")]
        public PlantableAreaConfig[] plantableAreas;

        [Header("金币配置")]
        [Range(1, 5)] public int coinSpawnCount;
        [Range(30, 60)] public float coinSpawnInterval;

        [Header("植物配置")]
        [Range(1, 30), Tooltip("植物生成检查间隔时间")] public float plantCheckInterval = 10f;
        [Range(0, 1), Tooltip("植物生成概率")] public float spawnPlantProbability = 0.5f;

        [Header("经济配置")]
        public int sellPrice;

        private void OnEnable()
        {
            if (string.IsNullOrEmpty(guid))
            {
                guid = System.Guid.NewGuid().ToString();
            }
        }

    }


#if UNITY_EDITOR
    [CustomEditor(typeof(StoneDataSO))]
    [CanEditMultipleObjects]
    public class StoneDataSOEditor : Editor
    {
        StoneDataSO so;

        private void OnEnable()
        {
            so = target as StoneDataSO;
        }

        public override void OnInspectorGUI()
        {
            // 绘制默认的Inspector界面
            DrawDefaultInspector();

            // 绘制icon预览
            if (so.icon != null)
            {
                UIUtil.ShowSpritePreview(so.icon, $"{so.stoneName}图标预览");
            }

            // 绘制种植区域大小
            if (so.plantableAreas != null && so.plantableAreas.Length > 0)
            {
                EditorGUILayout.Space();
                EditorGUILayout.LabelField("种植区域信息", EditorStyles.boldLabel);
                EditorGUILayout.Space();

                foreach (var area in so.plantableAreas)
                {
                    EditorGUILayout.BeginVertical(GUI.skin.box);
                    EditorGUILayout.LabelField($"区域 ID: {area.areaId}", EditorStyles.boldLabel);
                    EditorGUILayout.LabelField($"位置: ({area.position.x}, {area.position.y})");
                    EditorGUILayout.LabelField($"标签: {area.spawnTag}");
                    EditorGUILayout.LabelField($"大小标签: {area.sizeTag}");
                    EditorGUILayout.EndVertical();
                    EditorGUILayout.Space();
                }
            }

            // 添加跳转到文件按钮
            if (GUILayout.Button("跳转到文件", GUILayout.Height(24)))
            {
                // 选中并高亮显示对应的 Asset 文件
                Selection.activeObject = target;
                EditorGUIUtility.PingObject(target);
            }
        }
    }

#endif

    [System.Serializable]
    public class PlantableAreaConfig
    {
        public int areaId;
        public Vector2 position;
        public PlantSystem.SpawnTag spawnTag;
        public PlantSystem.SizeTag sizeTag;
    }

}
