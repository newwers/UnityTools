﻿using UnityEngine;
using StateMachineSystem;
using PlantSystem;
using System.Collections.Generic;


#if UNITY_EDITOR
using UnityEditor;
#endif

namespace StoneSystem
{
    public class Stone : MonoBehaviour
    {
        [Header("基本信息")]
        public string instanceId;

        [Header("石头数据")]
        public StoneDataSO stoneData;

        [Header("状态机")]
        public StateMachine stateMachine;

        [Header("植物生成")]
        public Transform flowerParent;
        private float nextPlantCheckTime;

        [Header("区域植物记录")]
        private Dictionary<int, PlantSystem.Plant> areaPlants = new Dictionary<int, PlantSystem.Plant>();

        [Header("金币生成")]
        private float nextCoinSpawnTime;

        [Header("鼠标交互")]
        private bool isBeingPickedUp = false;
        private Vector3 mouseOffset;
        private float pickUpTime;
        private const float longPressDuration = 0.5f; // 长按时间阈值

        private void Awake()
        {
            // 初始化实例id
            if (string.IsNullOrEmpty(instanceId))
            {
                instanceId = System.Guid.NewGuid().ToString();
            }

            // 初始化状态机引用
            if (stateMachine == null)
            {
                stateMachine = GetComponent<StateMachine>();
                if (stateMachine == null)
                {
                    Debug.LogWarning("石头上没有StateMachine组件，将无法进行状态判断");
                }
            }

            // 初始化时间
            if (stoneData != null)
            {
                nextPlantCheckTime = Time.time + stoneData.plantCheckInterval;
                nextCoinSpawnTime = Time.time + stoneData.coinSpawnInterval;
            }
            else
            {
                // 默认值，防止空引用错误
                nextPlantCheckTime = Time.time + 10f;
            }
        }

        private void Update()
        {
            // 鼠标交互逻辑
            HandleMouseInteraction();

            // 检查是否需要生成植物
            if (!isBeingPickedUp && Time.time >= nextPlantCheckTime)
            {
                CheckPlantSpawn();
                if (stoneData != null)
                {
                    nextPlantCheckTime = Time.time + stoneData.plantCheckInterval;
                }
                else
                {
                    // 默认值，防止空引用错误
                    nextPlantCheckTime = Time.time + 10f;
                }
            }

            // 检查是否需要生成金币
            if (!isBeingPickedUp && stoneData != null && Time.time >= nextCoinSpawnTime)
            {
                SpawnCoins();
                nextCoinSpawnTime = Time.time + stoneData.coinSpawnInterval;
            }

            // 抓取状态下跟随鼠标移动
            if (isBeingPickedUp)
            {
                FollowMouse();
            }
        }

        /// <summary>
        /// 处理鼠标交互
        /// </summary>
        private void HandleMouseInteraction()
        {
            // 检测鼠标右键按下
            if (Input.GetMouseButtonDown(1))
            {
                // 检查鼠标是否在石头上
                Vector3 mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
                RaycastHit2D hit = Physics2D.Raycast(mousePos, Vector2.zero);

                if (hit.collider != null && hit.collider.gameObject == gameObject)
                {
                    // 记录按下时间
                    pickUpTime = Time.time;
                    // 计算鼠标偏移量
                    mouseOffset = transform.position - mousePos;
                }
            }

            // 检测鼠标右键长按
            if (Input.GetMouseButton(1))
            {
                // 检查是否已经达到长按时间
                if (Time.time - pickUpTime >= longPressDuration)
                {
                    // 检查鼠标是否在石头上
                    Vector2 mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
                    RaycastHit2D hit = Physics2D.Raycast(mousePos, Vector2.zero);

                    if (hit.collider != null && hit.collider.gameObject == gameObject && !isBeingPickedUp)
                    {
                        // 抓取石头
                        PickUpStone();
                    }
                }
            }

            // 检测鼠标右键释放
            if (Input.GetMouseButtonUp(1))
            {
                // 重置按下时间
                pickUpTime = 0;
            }

            // 检测鼠标左键点击
            if (Input.GetMouseButtonDown(0))
            {
                // 检查鼠标是否在石头上
                Vector2 mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
                RaycastHit2D hit = Physics2D.Raycast(mousePos, Vector2.zero);

                if (hit.collider != null && hit.collider.gameObject == gameObject)
                {
                    // 触发植物晃动
                    TriggerPlantsShake();

                    // 如果石头正在被抓取，则放下石头
                    if (isBeingPickedUp)
                    {
                        DropStone();
                    }
                }
            }
        }

        /// <summary>
        /// 抓取石头
        /// </summary>
        private void PickUpStone()
        {
            if (stateMachine != null)
            {
                stateMachine.SetState(StateType.PickUp);
                isBeingPickedUp = true;
                TriggerPlantsShake();
                Debug.Log($"石头被抓起: {instanceId}");
            }
        }

        /// <summary>
        /// 放下石头
        /// </summary>
        private void DropStone()
        {
            if (stateMachine != null)
            {
                stateMachine.SetState(StateType.Lie);
                isBeingPickedUp = false;
                TriggerPlantsShake();
                Debug.Log($"石头被放下: {instanceId}");
            }
        }

        /// <summary>
        /// 跟随鼠标移动
        /// </summary>
        private void FollowMouse()
        {
            Vector3 mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            transform.position = mousePos + mouseOffset;
        }

        /// <summary>
        /// 触发石头上所有植物晃动
        /// </summary>
        private void TriggerPlantsShake()
        {
            // 遍历石头上所有的植物
            foreach (var plant in areaPlants.Values)
            {
                if (plant != null)
                {
                    // 触发植物晃动
                    plant.TriggerShake();
                }
            }
        }

        /// <summary>
        /// 检查并生成植物
        /// </summary>
        private void CheckPlantSpawn()
        {
            // 检查状态机是否存在以及当前状态，并且石头没有被抓取
            if (stateMachine != null && !isBeingPickedUp)
            {
                // 随机决定是否生成植物
                float probability = stoneData != null ? stoneData.spawnPlantProbability : 0.5f;
                if (Random.value <= probability && stoneData != null && stoneData.plantableAreas.Length > 0)
                {
                    // 1. 先获取可以种植区域所有满足条件的植物
                    List<PlantDataSO> eligiblePlants = GetEligiblePlants();

                    if (eligiblePlants.Count == 0)
                    {
                        Debug.Log("没有满足条件的植物可以种植");
                        return;
                    }

                    // 2. 然后获取稀有度
                    PlantSystem.Rarity targetRarity = RandomRarity();

                    // 3. 然后再根据稀有度，从匹配的里面随机一个植物
                    List<PlantDataSO> rarityMatchedPlants = eligiblePlants.FindAll(plant => plant.rarity == targetRarity);

                    // 如果没有匹配稀有度的植物，则使用所有满足条件的植物
                    if (rarityMatchedPlants.Count == 0)
                    {
                        rarityMatchedPlants = eligiblePlants;
                        Debug.Log($"没有稀有度为 {targetRarity} 的植物，使用所有满足条件的植物");
                    }

                    // 随机选择一种植物
                    int plantIndex = Random.Range(0, rarityMatchedPlants.Count);
                    PlantDataSO selectedPlant = rarityMatchedPlants[plantIndex];

                    // 4. 然后看这个植物匹配哪个可以种植的区域进行种植
                    List<PlantableAreaConfig> eligibleAreas = GetPlantEligibleAreas(selectedPlant);

                    if (eligibleAreas.Count == 0)
                    {
                        Debug.Log($"植物 {selectedPlant.plantName} 没有可以种植的区域");
                        return;
                    }

                    // 随机选择一个可种植区域
                    int areaIndex = Random.Range(0, eligibleAreas.Count);
                    PlantableAreaConfig selectedArea = eligibleAreas[areaIndex];

                    // 计算生成位置
                    Vector3 spawnPosition = transform.position + new Vector3(
                        selectedArea.position.x,
                        selectedArea.position.y,
                        0
                    );

                    // 生成植物
                    PlantSystem.Plant plant = PlantManager.Instance.SpawnPlant(selectedPlant, spawnPosition, Quaternion.identity, this);

                    if (plant != null)
                    {
                        // 将植物记录到对应的区域字典中
                        areaPlants[selectedArea.areaId] = plant;

                        // 监听植物销毁事件
                        StartCoroutine(MonitorPlantDestruction(plant, selectedArea.areaId));

                        Debug.Log($"在石头上生成了植物: {selectedPlant.plantName}，稀有度: {selectedPlant.rarity}，种植区域: {selectedArea.areaId}，植物实例ID: {plant.instanceId}，石头实例ID: {instanceId}");
                    }
                }
            }
        }

        /// <summary>
        /// 检查植物是否可以在指定区域生长
        /// </summary>
        /// <param name="plantData">植物数据</param>
        /// <param name="areaConfig">区域配置</param>
        /// <returns>是否可以生长</returns>
        private bool CanPlantGrowInArea(PlantDataSO plantData, PlantableAreaConfig areaConfig)
        {
            // 检查植物的spawnTags是否与区域的spawnTag匹配
            bool hasMatchingSpawnTag = false;
            if (plantData.spawnTags.Length == 0)
            {
                hasMatchingSpawnTag = true; // 没有标签限制，默认可以生长
            }
            else
            {
                foreach (var plantTag in plantData.spawnTags)
                {
                    if (plantTag == areaConfig.spawnTag)
                    {
                        hasMatchingSpawnTag = true;
                        break;
                    }
                }
            }

            // 检查植物的sizeTag是否与区域的sizeTag匹配
            bool hasMatchingSizeTag = (plantData.sizeTag == areaConfig.sizeTag);

            // 只有同时满足spawnTag和sizeTag匹配，才能生长
            return hasMatchingSpawnTag && hasMatchingSizeTag;
        }

        /// <summary>
        /// 生成金币
        /// </summary>
        private void SpawnCoins()
        {
            if (stoneData != null)
            {
                // 这里可以实现金币生成逻辑
                // 例如：生成指定数量的金币，并赋予随机速度
                Debug.Log($"石头生成了 {stoneData.coinSpawnCount} 个金币");
            }
        }

        /// <summary>
        /// 获取石头的移动速度
        /// </summary>
        /// <returns>移动速度</returns>
        public float GetMoveSpeed()
        {
            return stoneData != null ? stoneData.moveSpeed : 0f;
        }

        /// <summary>
        /// 获取石头的出售价格
        /// </summary>
        /// <returns>出售价格</returns>
        public int GetSellPrice()
        {
            return stoneData != null ? stoneData.sellPrice : 0;
        }

        /// <summary>
        /// 检查区域是否已满（已有植物）
        /// </summary>
        /// <param name="areaId">区域ID</param>
        /// <returns>区域是否已满</returns>
        private bool IsAreaFull(int areaId)
        {
            // 检查字典中是否有该区域的记录
            return areaPlants.ContainsKey(areaId);
        }

        /// <summary>
        /// 获取所有满足条件的植物
        /// </summary>
        /// <returns>满足条件的植物列表</returns>
        private List<PlantDataSO> GetEligiblePlants()
        {
            List<PlantDataSO> eligiblePlants = new List<PlantDataSO>();

            if (stoneData == null || stoneData.plantableAreas == null)
            {
                return eligiblePlants;
            }

            // 从PlantManager获取所有可种植的植物信息
            PlantDataSO[] allPlants = PlantManager.Instance.GetAllPlantData();
            if (allPlants == null)
            {
                return eligiblePlants;
            }

            // 遍历所有可种植区域
            foreach (var area in stoneData.plantableAreas)
            {
                // 检查区域是否已满
                if (IsAreaFull(area.areaId))
                {
                    continue;
                }

                // 遍历所有可用植物
                foreach (var plant in allPlants)
                {
                    // 检查植物是否满足区域条件
                    if (CanPlantGrowInArea(plant, area))
                    {
                        // 如果植物不在列表中，则添加
                        if (!eligiblePlants.Contains(plant))
                        {
                            eligiblePlants.Add(plant);
                        }
                    }
                }
            }

            return eligiblePlants;
        }

        /// <summary>
        /// 获取指定植物可以种植的所有区域
        /// </summary>
        /// <param name="plant">植物数据</param>
        /// <returns>可以种植的区域列表</returns>
        private List<PlantableAreaConfig> GetPlantEligibleAreas(PlantDataSO plant)
        {
            List<PlantableAreaConfig> eligibleAreas = new List<PlantableAreaConfig>();

            if (stoneData == null || stoneData.plantableAreas == null)
            {
                return eligibleAreas;
            }

            // 遍历所有可种植区域
            foreach (var area in stoneData.plantableAreas)
            {
                // 检查区域是否已满
                if (IsAreaFull(area.areaId))
                {
                    continue;
                }

                // 检查植物是否可以在该区域生长
                if (CanPlantGrowInArea(plant, area))
                {
                    eligibleAreas.Add(area);
                }
            }

            return eligibleAreas;
        }

        /// <summary>
        /// 检查石头上是否有符合条件的植物
        /// 符合条件：有植物且至少有一株灌溉值高于5
        /// </summary>
        /// <returns>是否有符合条件的植物</returns>
        public bool HasEligiblePlants()
        {
            // 检查石头上是否有植物
            if (areaPlants.Count == 0)
            {
                return false;
            }

            // 检查是否有植物灌溉值高于5
            foreach (var plant in areaPlants.Values)
            {
                if (plant != null && plant.currentIrrigationValue > 5)
                {
                    return true;
                }
            }

            // 没有符合条件的植物
            return false;
        }

        /// <summary>
        /// 随机生成稀有度
        /// </summary>
        /// <returns>随机的稀有度</returns>
        private PlantSystem.Rarity RandomRarity()
        {
            // 稀有度概率分布
            float randomValue = Random.value;

            if (randomValue < 0.6f) // 60% 概率
            {
                return PlantSystem.Rarity.Common;
            }
            else if (randomValue < 0.85f) // 25% 概率
            {
                return PlantSystem.Rarity.Rare;
            }
            else if (randomValue < 0.95f) // 10% 概率
            {
                return PlantSystem.Rarity.Epic;
            }
            else // 5% 概率
            {
                return PlantSystem.Rarity.Legendary;
            }
        }

        /// <summary>
        /// 监听植物销毁事件
        /// </summary>
        /// <param name="plant">要监听的植物</param>
        /// <param name="areaId">区域ID</param>
        /// <returns>协程</returns>
        private System.Collections.IEnumerator MonitorPlantDestruction(PlantSystem.Plant plant, int areaId)
        {
            // 持续检查植物是否存在
            while (plant != null)
            {
                yield return null;
            }

            // 植物销毁后，从区域字典中移除记录
            if (areaPlants.ContainsKey(areaId))
            {
                areaPlants.Remove(areaId);
                Debug.Log($"植物已销毁，从区域 {areaId} 中移除记录，石头实例ID: {instanceId}");
            }
        }
    }

#if UNITY_EDITOR
    [CustomEditor(typeof(Stone))]
    [CanEditMultipleObjects]
    public class StoneEditor : Editor
    {
        private Stone stone;

        private void OnEnable()
        {
            stone = target as Stone;
        }

        public override void OnInspectorGUI()
        {
            base.OnInspectorGUI();

            // 添加跳转到文件按钮
            if (GUILayout.Button("跳转到石头数据文件", GUILayout.Height(24)))
            {
                if (stone.stoneData != null)
                {
                    Selection.activeObject = stone.stoneData;
                    EditorGUIUtility.PingObject(stone.stoneData);
                }
            }
        }

        private void OnSceneGUI()
        {
            if (stone == null || stone.stoneData == null || stone.stoneData.plantableAreas == null)
                return;

            // 绘制可种植区域
            foreach (var area in stone.stoneData.plantableAreas)
            {
                // 计算区域的世界坐标
                Vector3 position = stone.transform.position + new Vector3(
                    area.position.x,
                    area.position.y,
                    0
                );

                // 绘制区域位置点
                Handles.color = Color.green;
                Handles.SphereHandleCap(0, position, Quaternion.identity, 0.2f, EventType.Repaint);

                // 绘制区域ID标签
                GUIStyle style = new GUIStyle();
                style.normal.textColor = Color.white;
                style.alignment = TextAnchor.MiddleCenter;
                style.fontSize = 12;

                Handles.Label(position, $"Area {area.areaId}", style);
            }
        }
    }
#endif
}
