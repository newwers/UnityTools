﻿using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public interface IDraggable
{
    void OnBeginDrag();
    void OnDrag();
    void OnEndDrag(bool isDrag);

    void OnClick();

    bool CanDrag();
}

/// <summary>
/// 单例拖拽管理器：同一时间只有一个拖拽目标
/// 管理实现了IDraggable的目标，并在拖拽开始/进行/结束时通知目标
/// 现在支持从场景拖拽到UGUI并从UGUI拖回场景的流程。
/// </summary>
public class DragManager : BaseMonoSingleClass<DragManager>
{

    [System.Serializable]
    public class DragEvent : UnityEvent<GameObject> { }

    [Header("检测设置")]
    [SerializeField] private bool detect2D = true; // 默认检测2D碰撞
    [SerializeField] private LayerMask interactableLayer = ~0; // 可交互层
    [SerializeField] private string interactableTag = "Interactable"; // 可交互标签（可选）

    [Header("UI")]
    [SerializeField] private Canvas uiCanvas; // 如果没有指定，会自动查找场景中的Canvas

    [Header("事件")]
    public DragEvent onDragStarted;    // 开始拖拽时触发
    public DragEvent onDragging;       // 拖拽过程中触发
    public DragEvent onDragEnded;      // 拖拽结束时触发

    [Header("调试")]
    [SerializeField] private bool debugMode = false;

    // 私有变量
    private Camera mainCamera;
    private GameObject currentDraggedObject;
    private Vector3 offset;
    private float zDistance;
    private bool isDragging = false;
    private Vector3 m_MouseClickPos;

    // UI dragging helpers
    private bool draggingUI = false;
    private RectTransform currentRectTransform;
    private Canvas currentObjectCanvas;
    private Vector2 uiOffset;

    private IDraggable current;

    public IDraggable Current => current;

    public bool IsDragging => current != null;

    protected override void Awake()
    {
        base.Awake();
        // 获取主相机
        mainCamera = Camera.main;
        if (uiCanvas == null)
        {
            uiCanvas = FindObjectOfType<Canvas>();
        }
    }

    private void Update()
    {
        HandleMouseInput();
    }

    private void HandleMouseInput()
    {
        // 鼠标按下
        if (Input.GetMouseButtonDown(0))
        {
            StartDrag();
        }

        // 鼠标按住
        if (Input.GetMouseButton(0) && isDragging)
        {
            OnDrag();
        }

        // 鼠标释放
        if (Input.GetMouseButtonUp(0))
        {
            EndDrag(isDragging);
        }
    }

    private void StartDrag()
    {
        // 首先尝试检测UI上的可拖拽物（支持从UI再次拖回场景）
        GameObject hitObject = null;

        if (EventSystem.current != null && uiCanvas != null && EventSystem.current.IsPointerOverGameObject())
        {
            var uiHit = RaycastUI();
            if (uiHit != null)
            {
                hitObject = uiHit;
            }
        }

        // 如果没有命中UI，再检测场景2D/3D物体
        if (hitObject == null)
        {
            Ray ray = mainCamera.ScreenPointToRay(Input.mousePosition);

            if (detect2D)
            {
                // 2D射线检测
                RaycastHit2D[] hits = RayCastAll2D();

                hits = hits.OrderByDescending(hit =>
                {
                    var go = hit.collider.gameObject;
                    //if (go.GetComponent<FloatingObject>() != null) return 3;    // FloatingObject 优先级最高
                    //if (go.GetComponent<PerchableObject>() != null) return 2;  // PerchableObject 次之
                    return 1;                                                   // 其他物体最低
                })
    //.ThenBy(hit => hit.distance)  // 距离作为次要排序条件
    .ToArray();


                if (hits != null && hits.Length > 0)
                {
                    var hit = hits[0];
                    // 检查标签（如果设置了标签）
                    if (string.IsNullOrEmpty(interactableTag) || hit.collider.CompareTag(interactableTag))
                    {
                        hitObject = hit.collider.gameObject;
                        m_MouseClickPos = Input.mousePosition;

                        if (debugMode)
                        {
                            Debug.Log($"检测到2D物体: {hitObject.name}, 位置: {hit.point}");
                        }
                    }
                }
            }
            else
            {
                // 3D射线检测
                RaycastHit hit;
                if (Physics.Raycast(ray, out hit, Mathf.Infinity, interactableLayer))
                {
                    // 检查标签（如果设置了标签）
                    if (string.IsNullOrEmpty(interactableTag) || hit.collider.CompareTag(interactableTag))
                    {
                        hitObject = hit.collider.gameObject;
                        m_MouseClickPos = Input.mousePosition;

                        if (debugMode)
                        {
                            Debug.Log($"检测到3D物体: {hitObject.name}, 位置: {hit.point}");
                        }
                    }
                }
            }
        }

        if (hitObject == null)
        {
            return;
        }

        // 如果检测到物体，开始拖拽

        var draggable = hitObject.GetComponent<IDraggable>();

        if (draggable == null)
        {
            return;
        }

        currentDraggedObject = hitObject;
        SetDraggedObject(draggable);
        isDragging = true;

        // 计算偏移量
        // 特殊处理 UI 元素，使其在拖拽时以 UI 坐标跟随鼠标（并保存偏移）
        currentObjectCanvas = currentDraggedObject.GetComponentInParent<Canvas>();
        currentRectTransform = currentDraggedObject.GetComponent<RectTransform>();
        if (currentObjectCanvas != null && currentRectTransform != null)
        {
            draggingUI = true;
            Camera uiCam = currentObjectCanvas.renderMode == RenderMode.ScreenSpaceOverlay ? null : currentObjectCanvas.worldCamera;
            RectTransform canvasRect = currentObjectCanvas.transform as RectTransform;
            Vector2 localPoint;
            RectTransformUtility.ScreenPointToLocalPointInRectangle(canvasRect, Input.mousePosition, uiCam, out localPoint);
            // preserve offset so grabbed point remains under cursor
            uiOffset = currentRectTransform.anchoredPosition - localPoint;
        }
        else
        {
            draggingUI = false;
            if (detect2D)
            {
                Vector3 mouseWorldPos = mainCamera.ScreenToWorldPoint(Input.mousePosition);
                offset = currentDraggedObject.transform.position - mouseWorldPos;
                offset.z = 0;
            }
            else
            {
                zDistance = mainCamera.WorldToScreenPoint(currentDraggedObject.transform.position).z;
                Vector3 mouseWorldPos = mainCamera.ScreenToWorldPoint(
                    new Vector3(Input.mousePosition.x, Input.mousePosition.y, zDistance));
                offset = currentDraggedObject.transform.position - mouseWorldPos;
            }
        }

        // 触发开始拖拽事件
        onDragStarted?.Invoke(currentDraggedObject);
        draggable.OnBeginDrag();

        if (debugMode)
        {
            Debug.Log($"开始拖拽: {currentDraggedObject.name}");
        }
    }

    /// <summary>
    /// 尝试进行UI射线检测，返回第一个拥有IDraggable组件的UI对象
    /// </summary>
    /// <returns></returns>
    private GameObject RaycastUI()
    {
        if (EventSystem.current == null || uiCanvas == null) return null;

        var gr = uiCanvas.GetComponent<GraphicRaycaster>();
        if (gr == null) return null;

        PointerEventData ped = new PointerEventData(EventSystem.current);
        ped.position = Input.mousePosition;

        List<RaycastResult> results = new List<RaycastResult>();
        gr.Raycast(ped, results);

        if (results.Count == 0) return null;

        // 找到第一个带有IDraggable的GameObject
        foreach (var r in results)
        {
            if (r.gameObject == null) continue;
            var draggable = r.gameObject.GetComponent<IDraggable>();
            if (draggable != null) return r.gameObject;

            // 有时组件在父物体上
            var drParent = r.gameObject.GetComponentInParent<MonoBehaviour>() as IDraggable;
            if (drParent != null) return (drParent as MonoBehaviour).gameObject;
        }

        return null;
    }

    public RaycastHit2D[] RayCastAll2D()
    {
        Ray ray = mainCamera.ScreenPointToRay(Input.mousePosition);
        return Physics2D.RaycastAll(ray.origin, ray.direction, Mathf.Infinity, interactableLayer);
    }

    private void OnDrag()
    {
        if (currentDraggedObject == null) return;
        if (Current != null && Current.CanDrag() == false)
        {
            return;
        }

        Vector3 mousePosition = Input.mousePosition;

        if (draggingUI && currentRectTransform != null && currentObjectCanvas != null)
        {
            Camera uiCam = currentObjectCanvas.renderMode == RenderMode.ScreenSpaceOverlay ? null : currentObjectCanvas.worldCamera;
            RectTransform canvasRect = currentObjectCanvas.transform as RectTransform;
            Vector2 localPoint;
            RectTransformUtility.ScreenPointToLocalPointInRectangle(canvasRect, mousePosition, uiCam, out localPoint);
            currentRectTransform.anchoredPosition = localPoint + uiOffset;
        }
        else if (detect2D)
        {
            // 2D拖拽
            Vector3 worldPosition = mainCamera.ScreenToWorldPoint(mousePosition);
            worldPosition += offset;
            worldPosition.z = currentDraggedObject.transform.position.z; // 保持Z轴不变
            currentDraggedObject.transform.position = worldPosition;
        }
        else
        {
            // 3D拖拽
            mousePosition.z = zDistance;
            Vector3 worldPosition = mainCamera.ScreenToWorldPoint(mousePosition);
            worldPosition += offset;
            currentDraggedObject.transform.position = worldPosition;
        }

        // 触发拖拽中事件
        onDragging?.Invoke(currentDraggedObject);
        Current?.OnDrag();
    }

    private void EndDrag(bool isDrag)
    {
        if (currentDraggedObject == null) return;

        // 如果拖拽的是场景中的FloatingObject并且释放在UI上，尝试交给UI Drop Zone 处理
        //if (Current != null && Current is FloatingObject && EventSystem.current != null && EventSystem.current.IsPointerOverGameObject())
        //{
        //    var floating = Current as FloatingObject;
        //    if (TryHandleUIDrop(floating))
        //    {
        //        // Drop handled by UI, still notify target
        //        onDragEnded?.Invoke(currentDraggedObject);
        //        Current?.OnEndDrag(isDrag);

        //        // 重置内部状态并返回
        //        currentDraggedObject = null;
        //        isDragging = false;
        //        draggingUI = false;
        //        currentRectTransform = null;
        //        currentObjectCanvas = null;
        //        ForceClear(Current);
        //        return;
        //    }
        //}

        // 触发结束拖拽事件
        onDragEnded?.Invoke(currentDraggedObject);
        Current?.OnEndDrag(isDrag);

        if (m_MouseClickPos == Input.mousePosition)
        {
            Current?.OnClick();
        }

        if (debugMode)
        {
            Debug.Log($"结束拖拽: {currentDraggedObject.name}");
        }

        // 重置状态
        currentDraggedObject = null;
        isDragging = false;
        draggingUI = false;
        currentRectTransform = null;
        currentObjectCanvas = null;
        ForceClear(Current);
    }

    // 公开方法
    public void SetDetectionMode(bool is2D)
    {
        detect2D = is2D;
        if (debugMode)
        {
            Debug.Log($"切换检测模式为: {(is2D ? "2D" : "3D")} ");
        }
    }

    public void SetInteractableLayer(LayerMask layer)
    {
        interactableLayer = layer;
    }

    public void SetInteractableTag(string tag)
    {
        interactableTag = tag;
    }


    /// <summary>
    /// 强制清除当前拖拽目标（例如对象销毁时）
    /// </summary>
    public void ForceClear(IDraggable draggable)
    {
        if (current == draggable) current = null;
    }

    void SetDraggedObject(IDraggable draggable)
    {
        current = draggable;
    }

    /// <summary>
    /// 当在UI上释放场景中的FloatingObject时，尝试找到UI上的DropZone并将物体转为UI代理
    /// </summary>
    //private bool TryHandleUIDrop(FloatingObject floating)
    //{
    //    if (uiCanvas == null || EventSystem.current == null) return false;

    //    var gr = uiCanvas.GetComponent<GraphicRaycaster>();
    //    if (gr == null) return false;

    //    PointerEventData ped = new PointerEventData(EventSystem.current) { position = Input.mousePosition };
    //    List<RaycastResult> results = new List<RaycastResult>();
    //    gr.Raycast(ped, results);

    //    foreach (var r in results)
    //    {
    //        if (r.gameObject == null) continue;

    //        var zone = r.gameObject.GetComponent<UIDropZone>();
    //        if (zone == null)
    //        {
    //            // 检查父物体
    //            zone = r.gameObject.GetComponentInParent<UIDropZone>();
    //        }

    //        if (zone != null)
    //        {
    //            if (zone.TryDrop(floating))
    //            {
    //                return true;
    //            }
    //        }
    //    }

    //    return false;
    //}
}
