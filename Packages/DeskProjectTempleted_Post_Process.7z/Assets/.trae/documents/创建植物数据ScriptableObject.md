# 目标位置更新规则修改计划

## 任务目标

修改Walk状态的目标位置更新规则，改为走到目标点附近后更新下一个目标点位置，去掉时间间隔，改为距离检测。

## 实现步骤

### 1. 修改WalkStateSO.cs配置文件

* **移除targetUpdateInterval字段**

  * 删除原有的targetUpdateInterval配置

* **添加targetReachDistance字段**

  * 添加新的距离检测配置，默认值为0.1

  * 添加适当的范围限制（例如0.01f到1f）

### 2. 修改WalkState.cs状态类

* **移除lastTargetUpdateTime字段**

  * 删除不再使用的时间跟踪字段

* **修改Enter方法**

  * 移除对lastTargetUpdateTime的初始化

* **修改Update方法**

  * 移除基于时间间隔的目标位置更新逻辑

  * 添加基于距离的目标位置更新逻辑

  * 当角色距离目标位置小于等于targetReachDistance时，生成新的目标位置

### 3. 实现细节

* **距离计算**

  * 使用Vector3.Distance计算当前位置和目标位置的距离

  * 当距离小于等于targetReachDistance时，生成新的目标位置

* **保持其他功能不变**

  * 保持移动逻辑不变

  * 保持朝向控制逻辑不变

### 4. 测试验证

* 确保所有修改都能正确编译

* 验证角色在走到目标点附近后会自动更新下一个目标位置

* 验证距离检测是否正常工作

## 技术实现要点

* 使用Vector3.Distance计算角色与目标位置的距离

* 在Update方法中实时检测距离并更新目标位置

* 保持代码风格与现有代码一致

* 确保修改不会影响其他功能

