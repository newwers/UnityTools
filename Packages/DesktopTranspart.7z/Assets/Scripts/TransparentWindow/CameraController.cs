﻿using UnityEngine;


public class CameraController : MonoBehaviour
{
    public Camera cam;
    public Color transpareColor;
    public UnityEngine.Rendering.Universal.PixelPerfectCamera pixelPerfectCamera;

    private void Awake()
    {
#if !UNITY_EDITOR
        cam.backgroundColor = transpareColor;
#endif

        //根据屏幕分辨率设置相机的像素完美
        if (pixelPerfectCamera != null)
        {
            pixelPerfectCamera.assetsPPU = 48; // 假设游戏设计为9:16的纵向屏幕

            if (Screen.width == 1920 && Screen.height == 1080)
            {
                pixelPerfectCamera.refResolutionX = (int)(Screen.width / 2f);
                pixelPerfectCamera.refResolutionY = (int)(Screen.height / 2f);
                //LogManager.Log("屏幕1920*1080 放大2");
            }
            else
            {
                pixelPerfectCamera.refResolutionX = Screen.width / 2; // 设置参考分辨率宽度
                pixelPerfectCamera.refResolutionY = Screen.height / 2; // 设置参考分辨率高度
            }
        }
    }
}
